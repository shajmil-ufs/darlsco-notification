var mysql = require("mysql2");
var connection = mysql.createPool({
  host: 'localhost',
  
  user: 'root',
  password: 'TrackB0xPa$$w0rd',
  database: "trackbox_abc",
  port:'3306',
  multipleStatements: true
});
module.exports = connection;
